module.exports = {
  HOST: "USER-20220418SS",
  USER: "sa",
  PASSWORD: "root.123",
  DB: "test"
};