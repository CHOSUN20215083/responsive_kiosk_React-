// 引入腾讯云SMS服务的SDK
const tencentcloud = require("tencentcloud-sdk-nodejs");

// 导入SMS模块的client类
const SmsClient = tencentcloud.sms.v20210111.Client;

// 实例化一个认证对象，入参需要传入腾讯云账户secretId，secretKey
const clientConfig = {
  credential: {
    secretId: "AKIDeIhtugEXgdx2ta3IJ6h4C6lV1JMBqMgm",
    secretKey: "xhDVYNzNahcIkyzmK2V0KQIwM5bDqOsB"
  },
  region: "", // 短信API服务地域（非必填）
  profile: {
    httpProfile: {
      endpoint: "sms.tencentcloudapi.com",
    },
  },
};

// 实例化要请求产品的client对象
const client = new SmsClient(clientConfig);

// 发送短信的参数
const params = {
  /* 短信应用ID: 在短信控制台添加应用后生成的实际SdkAppId，例如1400006666 */
  SmsSdkAppId: "1400907868",
  /* 短信签名内容 */
  SignName: "您的短信签名",
  /* 短信模板ID */
  TemplateId: "您的短信模板ID",
  /* 需要发送短信的手机号码 */
  PhoneNumberSet: ["+8618351956736"],
  /* 模板参数: 若无模板参数，则设置为空 */
  TemplateParamSet: ["1234", "5"],
};

// 调用发送短信方法
client.SendSms(params).then(
  (data) => {
    console.log(data);
  },
  (err) => {
    console.error("error", err);
  }
);
